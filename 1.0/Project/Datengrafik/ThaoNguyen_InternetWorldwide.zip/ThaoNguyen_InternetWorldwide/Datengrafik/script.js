function showDoku() {
    document.getElementById("dokuPanel").style.visibility = "visible";
}
hideDoku();

function hideDoku() {
    document.getElementById("dokuPanel").style.visibility = "hidden";
    document.getElementById("dokuPanel").style.display = "none";
}