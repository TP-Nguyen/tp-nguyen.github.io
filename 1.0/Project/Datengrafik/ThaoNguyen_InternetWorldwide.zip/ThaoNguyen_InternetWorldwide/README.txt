NGUYEN, Phuong Thao
5034297

Um das Projekt lokal anzuzeigen bitte die Datei Datenvisiualisierung.html öffnen. 
Falls es zu Fetch Probleme kommen kann bitte die Extension runterladen. 
https://chrome.google.com/webstore/detail/web-server-for-chrome/ofhbbkphhbklhfoeikjpcbhemlocgigb/related?hl=en
https://addons.mozilla.org/de/firefox/addon/live-server-web-extension/

Oder mit folgenden link können die website aufrufen
https://tp-nguyen.github.io/website/Project/Datenvisiualisierung.html