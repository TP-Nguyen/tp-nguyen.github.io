$(document).ready(function () {
    $('#menu').click(function () {
        $('nav ul').toggleClass('showMenu');
    })
})